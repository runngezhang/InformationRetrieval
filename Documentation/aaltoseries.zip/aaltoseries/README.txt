aaltoseries.cls -- A LaTeX class that can be used for Aalto University publication series publications

See the accompanying documentation in aaltoseries.pdf for a user manual. Examples of the use of the aaltoseries class can be found in the examples/ folder. The example files contain short descriptions of the features available in the different publication types, and more detailed descriptions are found in the user manual. Read the file LICENSES.txt for publication licenses of the files aaltoseries.cls and aaltoseries.pdf. The publication licenses are also given in the documentation.

For installation, move/copy aaltoseries.cls to a location where LaTeX can find it.
